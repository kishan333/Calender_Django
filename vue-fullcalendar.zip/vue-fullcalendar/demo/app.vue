<template>
  <div>
  	<p>
  		Here is the demo of vue-fullcalendar, no jquery fullcalendar.js required!
      <button @click="getData()" value="get data">Get data</button>
      <!-- <p>{{ posts }}</p> -->
  	</p>
    <!-- <button @click="getData()" >Get data</button>
    <p>{{ demoEvents }}</p> -->
    <!-- events="demoEvents"  -->
      
    <full-calendar class="test-fc" :events="demoEvents"
      first-day='1' locale="fr"
      @changeMonth="changeMonth"
      @eventClick="eventClick"
      @dayClick="dayClick"
      @moreClick="moreClick"
      >
        
        <template slot="fc-event-card" scope="p">
            <p><i class="fa"></i> {{ p.event.title }}</p>
        </template>
        
    </full-calendar>
  </div>
</template>
<script>
import axios from 'axios';

//   export default {
//   name: 'HelloWorld',
//   // props: {
//   //   msg: String
//   // },
//   data: function() {
//     return {
//     posts : null,   
//     }
//   },
//   methods :{
//   getData() {
//     axios.get("http://localhost:8000/event_list/?format=json")
//     .then(response => {
//       // JSON responses are automatically parsed.
//       this.posts = response.data

//     })
//     .catch(e => {
//       this.errors.push(e)
//     })
//   }
//   }
// }

// let demoEvents = [
//     {
//       title    : 'Sunny 725-727',
//       start    : '2017-02-25',
//       end      : '2017-02-27',
//       cssClass : 'family'
//     },
//     {
//         title   : 'hello',
//         start   : '2020-02-05',
//         end     : '2020-02-06',
//     },
//     {
//       title : 'welcome',
//       start : '2020-01-27',
//       end : '2020-01-28',
//     },
//     {
//       title : 'holiday',
//       start : '2020-01-27',
//       end : '2020-01-29'
//     },
//     {
//         title : 'birthday',
//         start : '2020-01-28',
//         end : '2020-01-28'
//     },
//     {
//         title : 'submit date',
//         start : '2020-01-28',
//         end : '2020-01-29'
//     },
//     {
//         title : 'start date',
//         start : '2020-01-23',
//         end : '2020-01-23'
//     },
//     {
//         title : 'submit date',
//         start : '2020-01-28',
//         end : '2020-01-28'
//     },
//     {
//         title : 'submitted date',
//         start : '2020-01-29',
//         end : '2020-01-29'
//     },
//     {
//         title : 'marriage holiday Request',
//         start : '2020-02-01',
//         end : '2020-02-07',
//     },
//   ];

export default {
	data () {
		return {
            name:'Sunny!',
            // posts : null ,
           demoEvents: [] ,
            // events : [] ,   
        }
	},
  methods : {
    'changeMonth' (start, end, current) {
      console.log('changeMonth', start.format(), end.format(), current.format())
    },
    'eventClick' (event, jsEvent, pos) {
       console.log('eventClick', event, jsEvent, pos)
    },
    'dayClick' (day, jsEvent) {
      console.log('dayClick', day, jsEvent)
    },
    'moreClick' (day, events, jsEvent) {
      console.log('moreCLick', day, events, jsEvent)
    },
    'getData' () {
      console.log("hello")
      axios.get("http://localhost:8000/event_list/?format=json")
        .then(response => {
          // JSON responses are automatically parsed.
          this.demoEvents = response.data
        })
        .catch(e => {
          this.errors.push(e)
        } 
      )
    }
  },
    components : {
      'full-calendar' : require('src/fullCalendar')
    }
}

</script>
<style lang='scss'>
  .app{
    color:green;
  }
</style>