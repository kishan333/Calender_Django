<template>
  <div>
  	<p>
  		Here is the demo of vue-fullcalendar, no jquery fullcalendar.js required!
  	</p>
    <full-calendar class="test-fc" :events="fcEvents" 
      first-day='1' locale="fr"
      @changeMonth="changeMonth"
      @eventClick="eventClick"
      @dayClick="dayClick"
      @moreClick="moreClick">
        <template slot="fc-event-card" scope="p">
            <p><i class="fa"></i> {{ p.event.title }}</p>
        </template>
    </full-calendar>
  </div>
</template>
<script>
  // methods: {
  //     getQuestion: function() {
        
  //         let api_url = 'http://localhost:8000/pollstest/detail/'; 
  //         this.$http.get(api_url).then((response) => {
  //               console.log(response.content)
  //               //this.articles = response.data;

  //             })
  //             .catch((err) => {
  //             console.log(err);
  //             })
  //             }
  // }
let demoEvents = [
    {
      title    : 'Sunny 725-727',
      start    : '2017-02-25',
      end      : '2017-02-27',
      cssClass : 'family'
    },
    {
        title   : 'hello',
        start   : '2020-02-05',
        end     : '2020-02-06',
    },
    {
      title : 'welcome',
      start : '2020-01-27',
      end : '2020-01-28',
    },
    {
      title : 'holiday',
      start : '2020-01-27',
      end : '2020-01-29'
    },
    {
        title : 'birthday',
        start : '2020-01-28',
        end : '2020-01-28'
    },
    {
        title : 'submit date',
        start : '2020-01-28',
        end : '2020-01-29'
    },
    {
        title : 'start date',
        start : '2020-01-23',
        end : '2020-01-23'
    },
    {
        title : 'submit date',
        start : '2020-01-28',
        end : '2020-01-28'
    },
    {
        title : 'submitted date',
        start : '2020-01-29',
        end : '2020-01-29'
    },
    {
        title : 'marriage holiday Request',
        start : '2020-02-01',
        end : '2020-02-07',
    },
  ];

export default {
	data () {
		return {
            name:'Sunny!',
            fcEvents : demoEvents
        }
	},
  methods : {
    'changeMonth' (start, end, current) {
      console.log('changeMonth', start.format(), end.format(), current.format())
    },
    'eventClick' (event, jsEvent, pos) {
       console.log('eventClick', event, jsEvent, pos)
    },
    'dayClick' (day, jsEvent) {
      console.log('dayClick', day, jsEvent)
    },
    'moreClick' (day, events, jsEvent) {
      console.log('moreCLick', day, events, jsEvent)
    }
  },
  components : {
    'full-calendar' : require('src/fullCalendar')
  }
}
</script>
<style lang='scss'>
  .app{
    color:green;
  }
</style>