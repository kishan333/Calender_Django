import vueFullcalendar from './fullCalendar'

const fc = vueFullcalendar;

module.exports = fc;